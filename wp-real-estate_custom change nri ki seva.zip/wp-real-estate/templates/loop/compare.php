<?php
/**
 * Loop comparison
 *
 * This template can be overridden by copying it to yourtheme/listings/loop/comparison.php.
 */
if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly
}

$listing_id = wre_get_ID();
$wrapper_class = '';
$anchor_class = '';
$listings = wre_get_comparison_data();
if (!empty($listings) && in_array($listing_id, $listings)) {
	$wrapper_class = 'in';
	$anchor_class = 'hide';
}
?>
<div class="compare-wrapper">
	<!--<div class="compare-output <?php echo esc_attr( $wrapper_class ); ?>">-->
	<!--	<i class="wre-icon-compare"></i>-->
	<!--	<?php _e('Added to Compare', 'wp-real-estate'); ?>-->
	<!--</div>-->

	<!--<a href="#" class="add-to-compare <?php echo esc_attr( $anchor_class ); ?>" data-id="<?php echo esc_attr(wre_get_ID()); ?>">-->
	<!--	<i class="wre-icon-compare"></i>-->
	<!--	<?php _e('Add to Compare', 'wp-real-estate'); ?>-->
	<!--</a>-->
</div>


<a class="" href="#<?php echo esc_attr(wre_get_ID()); ?>">
<button class="fusion-button button-flat fusion-button-round button-large button-default button-1"><span class="fusion-button-text">Inquiry</span></button>
</a>

<div id="<?php echo esc_attr(wre_get_ID()); ?>" class="wre_loop_overlay">
	<div class="wre_loop_popup">
		<h2 class="widget-title"><?php echo __( 'Quick Contact', 'wp-real-estate' ); ?></h2>
		<a class="wre_loop_close" href="#">&times;</a>
		<div class="wre_loop_content">
                <div class="wre-contact-form" id="wre-contact">
                	<div class="message-wrapper"></div>
                	<?php echo do_shortcode( '[wre_contact_form]' ); ?>
                </div>
		</div>
	</div>
</div>

