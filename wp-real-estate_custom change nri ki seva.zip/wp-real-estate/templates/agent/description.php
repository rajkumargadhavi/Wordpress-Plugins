<?php
/**
 * Single agent description
 *
 * This template can be overridden by copying it to yourtheme/listings/agent/description.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

wre_get_agent_description( wre_agent_ID() );