<?php
/**
 * Single agent name
 *
 * This template can be overridden by copying it to yourtheme/listings/agent/name.php.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

wre_agent_name( wre_agent_ID() );