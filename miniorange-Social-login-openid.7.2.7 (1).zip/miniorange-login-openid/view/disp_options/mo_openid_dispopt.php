<?php
function mo_openid_disp_opt()
{
?>
    <form id="display" name="display" method="post" action="">
        <input type="hidden" name="option" value="mo_openid_enable_display" />
        <input type="hidden" name="mo_openid_enable_display_nonce" value="<?php echo wp_create_nonce( 'mo-openid-enable-display-nonce' ); ?>"/>
        <div class="mo_openid_table_layout" id="mo_openid_disp_opt_tour"><br/>
            <div style="width:40%; background:white; float:left; border: 1px transparent;">
                <b style="font-size: 17px">Select the options where you want to display the social login icons</b><br><br>
                <label class="mo_openid_checkbox_container">Default Login Form [wp-admin]
                    <input  type="checkbox" id="default_login_enable" name="mo_openid_default_login_enable" value="1" <?php checked( get_option('mo_openid_default_login_enable') == 1 );?> /><br>
                    <span class="mo_openid_checkbox_checkmark"></span>
                </label>

                <label class="mo_openid_checkbox_container">Default Registration Form
                    <input type="checkbox" id="default_register_enable" name="mo_openid_default_register_enable" value="1" <?php checked( get_option('mo_openid_default_register_enable') == 1 );?> /><br>
                    <span class="mo_openid_checkbox_checkmark"></span>
                </label>

                <label class="mo_openid_checkbox_container">Comment Form
                    <input type="checkbox" id="default_comment_enable" name="mo_openid_default_comment_enable" value="1" <?php checked( get_option('mo_openid_default_comment_enable') == 1 );?> /><br>
                    <span class="mo_openid_checkbox_checkmark"></span>
                </label>
                <label class="note_style" style="cursor: auto">Don't find your login page in above options use <code id='1'>[miniorange_social_login]</code><i style= "width: 11px;height: 9px;padding-left:2px;padding-top:3px" class="mofa mofa-fw mofa-lg mofa-copy mo_copy copytooltip" onclick="copyToClipboard(this, '#1', '#shortcode_url_copy')"><span id="shortcode_url_copy" class="copytooltiptext">Copy to Clipboard</span></i> to display social icons or <a onclick="mo_openid_support_form(this)">Contact Us</a></label>
                <br/><br/>
                <b style="font-size: 17px;">BuddyPress display options <a style="left: 1%; position: relative; text-decoration: none" class="mo-openid-premium" href="<?php echo add_query_arg( array('tab' => 'licensing_plans'), $_SERVER['REQUEST_URI'] ); ?>">PRO</a></b><br><br>

                <label class="mo_openid_checkbox_container_disable">Before BuddyPress Registration Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">Before BuddyPress Account Details
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">After BuddyPress Registration Form
                    <input type="checkbox"  /><br><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>
            </div>
            <div style="width:50%; background:white; float:right; border: 1px transparent;">
                <b style="font-size:17px;">Woocommerce display options <a style="left: 1%; position: relative; text-decoration: none" class="mo-openid-premium" href="<?php echo add_query_arg( array('tab' => 'licensing_plans'), $_SERVER['REQUEST_URI'] ); ?>">PRO</a></b><br><br><br>

                <label class="mo_openid_checkbox_container_disable">Before WooCommerce Login Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">Before 'Remember Me' of WooCommerce Login Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>
                <label class="mo_openid_checkbox_container_disable">After WooCommerce Login Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">Before WooCommerce Registration Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>
                <label class="mo_openid_checkbox_container_disable">Before 'Register button' of WooCommerce Registration Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">After WooCommerce Registration Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">Before WooCommerce Checkout Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>

                <label class="mo_openid_checkbox_container_disable">After WooCommerce Checkout Form
                    <input type="checkbox"  /><br>
                    <span class="mo_openid_checkbox_checkmark_disable"></span>
                </label>
            </div>
            <div style="height:available;display: inline; width:100%; background:white; float:right; border: 1px transparent; padding-bottom: 10px;" >
                <label class="mo_openid_checkbox_container">Display miniOrange logo with social login icons on selected form
                    <input type="checkbox" id="moopenid_logo_check" name="moopenid_logo_check" value="1"  <?php checked( get_option('moopenid_logo_check') == 1 );?> />
                    <span class="mo_openid_checkbox_checkmark"></span>
                </label>

            <br/><b style="padding: 10px"><input type="submit" name="submit" value="Save" style="width:150px;background-color:#0867b2;color:white;box-shadow:none;text-shadow: none;"  class="button button-primary button-large" /></b>

               <br><br> <label style="cursor: auto" class="note_style"> <a style="left: 1%; position: relative; text-decoration: none" class="mo-openid-premium" href="<?php echo add_query_arg( array('tab' => 'licensing_plans'), $_SERVER['REQUEST_URI'] ); ?>">PRO</a>&nbsp;&nbsp;&nbsp;&nbsp;These features are available in premium version only. To know more about the premium plugin <a href="https://plugins.miniorange.com/social-login-social-sharing ">click here</a>.</label>
                <h3  id="mo_openid_show_add_login_icons" onclick="show_license_options1(this.id)"><a id="openid_login_shortcode_title"  aria-expanded="false" ><span class="dashicons dashicons-arrow-down " ></span>Add Login Icons</a></h3>
                <div id="openid_login_shortcode" style="font-size:13px !important">
                    <ol>
                        <p>You can add login icons in the following areas from <strong>Display Options</strong>. For other areas(widget areas), use Login widget.</p>
                        <ol>
                            <li>Default Login Form: This option places login icons below the default login form on wp-login.</li>
                            <li>Default Registration Form: This option places login icons below the default registration form.</li>
                            <li>Comment Form: This option places login icons above the comment section of all your posts.</li>
                        </ol>
                    </ol>
                </div>

                <h3 id="mo_openid_show_add_login_icons1" onclick="show_add_login_icons1(this.id)"><a id="openid_sharing_shortcode_title"  ><span class="dashicons dashicons-arrow-down " ></span>Add Login Icons as Widget</a></h3>
                <div  id="openid_sharing_shortcode" style="font-size:13px !important">
                    <ol>
                        <li>Go to Widgets. Among the available widgets you
                            will find miniOrange Social Login Widget, drag it to the widget area where
                            you want it to appear.</li>
                        <li>Now logout and go to your site. You will see Social Login icon for which you enabled login.</li>
                        <li>Click that app icon and login with your existing app account to wordpress.</li>
                    </ol>
                </div>

                <h3 id="mo_openid_show_add_login_icons2" onclick="show_add_login_icons2(this.id)"><a   id="openid_comments_shortcode_title"  ><span class="dashicons dashicons-arrow-down" ></span>Using Shortcode</a></h3>
                <div  id="openid_comments_shortcode" style="font-size:13px !important">
                    <ol>
                        <p><?php echo"You can use this shortcode <code id='2'>[miniorange_social_login]</code><i style= \"width: 11px;height: 9px;padding-left:2px;padding-top:3px\" class=\"mofa mofa-fw mofa-lg mofa-copy mo_copy copytooltip\" onclick=\"copyToClipboard(this, '#2', '#shortcode_url2_copy')\"><span id=\"shortcode_url2_copy\" class=\"copytooltiptext\">Copy to Clipboard</span></i> to display social icons on any login page, post, popup and php pages."?></p>
                        <p><?php echo"* Detailed information about how to use shortcode is given in <a href=" . site_url() ."/wp-admin/admin.php?page=mo_openid_general_settings&tab=shortcodes>Shortcode</a> tab";?></p>
                    </ol>
                </div>
            </div>
        </div>
    </form>
    <script>
        //to set heading name
        jQuery('#mo_openid_page_heading').text('Display Options');
        function show_license_options1(click_id){
            var span = jQuery('#' + click_id).find('span').attr('class');
            if (span.includes('dashicons-arrow-right')){
                jQuery('#mo_openid_show_add_login_icons').find('span').removeClass( "dashicons-arrow-right" );
                jQuery('#mo_openid_show_add_login_icons').find('span').addClass( "dashicons-arrow-down" );
            }
            else if(span.includes('dashicons-arrow-down')) {
                jQuery('#mo_openid_show_add_login_icons').find('span').removeClass( "dashicons-arrow-down" );
                jQuery('#mo_openid_show_add_login_icons').find('span').addClass( "dashicons-arrow-right" );
            }
            jQuery("#mo_openid_licence1").slideToggle(400);
        }

        function show_add_login_icons1(click_id){
            var span = jQuery('#' + click_id).find('span').attr('class');
            if (span.includes('dashicons-arrow-right')){
                jQuery('#mo_openid_show_add_login_icons1').find('span').removeClass( "dashicons-arrow-right" );
                jQuery('#mo_openid_show_add_login_icons1').find('span').addClass( "dashicons-arrow-down" );
            }
            else if(span.includes('dashicons-arrow-down')) {
                jQuery('#mo_openid_show_add_login_icons1').find('span').removeClass( "dashicons-arrow-down" );
                jQuery('#mo_openid_show_add_login_icons1').find('span').addClass( "dashicons-arrow-right" );
            }
        }

        function show_add_login_icons2(click_id){
            var span = jQuery('#' + click_id).find('span').attr('class');
            if (span.includes('dashicons-arrow-right')){

                jQuery('#mo_openid_show_add_login_icons2').find('span').removeClass( "dashicons-arrow-right" );
                jQuery('#mo_openid_show_add_login_icons2').find('span').addClass( "dashicons-arrow-down" );
            }
            else if(span.includes('dashicons-arrow-down')) {
                jQuery('#mo_openid_show_add_login_icons2').find('span').removeClass( "dashicons-arrow-down" );
                jQuery('#mo_openid_show_add_login_icons2').find('span').addClass( "dashicons-arrow-right" );
            }
        }
    </script>
    <?php
}