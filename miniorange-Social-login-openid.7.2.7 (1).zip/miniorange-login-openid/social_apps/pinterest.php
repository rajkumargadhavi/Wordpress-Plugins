<?php


class pinterest
{
    public $color="#D73532";
}