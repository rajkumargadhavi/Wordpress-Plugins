<?php


class tumblr
{
    public $color="#34465D";
}