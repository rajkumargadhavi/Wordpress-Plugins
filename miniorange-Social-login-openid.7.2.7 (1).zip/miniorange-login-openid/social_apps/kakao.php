<?php


class kakao
{
    public $color="#F9E000";
}