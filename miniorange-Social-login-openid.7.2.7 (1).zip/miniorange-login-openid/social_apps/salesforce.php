<?php


class salesforce
{
    public $color="#009DDC";
}