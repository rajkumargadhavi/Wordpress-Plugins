<?php


class vimeo
{
    public $color="#1FB7EB";
}