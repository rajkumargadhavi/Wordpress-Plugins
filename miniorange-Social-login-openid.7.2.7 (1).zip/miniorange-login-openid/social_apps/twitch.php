<?php


class twitch
{
    public $color="#6441A5";
}