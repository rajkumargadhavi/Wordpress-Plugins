<?php


class line
{
    public $color="#00B900";
}