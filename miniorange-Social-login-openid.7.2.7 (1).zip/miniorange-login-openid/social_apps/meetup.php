<?php


class meetup
{
    public $color="#EC1C40";
}