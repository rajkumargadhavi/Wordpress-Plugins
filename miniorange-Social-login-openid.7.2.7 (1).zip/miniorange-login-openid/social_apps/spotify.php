<?php


class spotify
{
    public $color="#1ED760";
}