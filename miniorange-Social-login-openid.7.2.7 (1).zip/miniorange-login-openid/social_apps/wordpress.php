<?php


class wordpress
{
    public $color="#346DA6";
}