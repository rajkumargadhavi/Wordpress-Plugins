<?php


class dribbble
{
    public $color="#E84C88";
}