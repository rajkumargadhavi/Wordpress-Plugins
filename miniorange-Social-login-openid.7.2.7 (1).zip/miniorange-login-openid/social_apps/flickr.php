<?php


class flickr
{
    public $color="#FF2F96";
}