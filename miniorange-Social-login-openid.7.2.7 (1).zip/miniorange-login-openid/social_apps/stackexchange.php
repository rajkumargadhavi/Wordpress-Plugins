<?php


class stackexchange
{
    public $color="#163B7F";
}