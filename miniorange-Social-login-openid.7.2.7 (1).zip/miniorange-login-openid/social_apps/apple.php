<?php


class apple
{
    public $color="#000000";
}