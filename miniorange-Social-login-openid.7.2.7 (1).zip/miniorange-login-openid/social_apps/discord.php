<?php


class discord
{
    public $color="#7289DA";
}