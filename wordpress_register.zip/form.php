

<form id="adduser" class="user-forms" action="" autocomplete="on" method="post" name="reg_form">

                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>First Name<sup>*</sup></label>
                            <input id="fullname" name="fullname" type="text" class="form-control blog-form-in" placeholder="First name">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Email<sup>*</sup></label>
                            <input id="email" name="email" type="text" class="form-control blog-form-in" placeholder="johndoe@example.com">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Password<sup>*</sup></label>
                            <input id="pass" name="pass" type="password" class="form-control blog-form-in" placeholder="Your Password">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Confirm Password<sup>*</sup></label>
                            <input id="cpass" name="cpass" type="password" class="form-control blog-form-in" placeholder="Confirm Password">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Mobile Number<sup>*</sup></label>

                            <div class="row">
                                <div class="col-lg-3 col-md-3 col-sm-3 col-12">
                                    <input id="p_code" name="p_code" type="text" class="form-control blog-form-in" placeholder="+91">
                                </div>
                                <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                                    <input id="phone" name="phone" type="text" class="form-control blog-form-in" placeholder="XX XX XX XX XX">
                                </div>
                            </div>
                        </div>
                        <!-- <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Country<sup>*</sup></label>
                           
                        </div> -->

                        
                            <!-- <label>State<sup>*</sup></label> -->
                            <!-- <input id="state" name="state" type="text" class="form-control blog-form-in" placeholder="State"> -->
                            <!-- <select class="sl-state">
                                    <option value="opt1">Option 1</option>
                                    <option value="opt2">Option 2</option>
                                    <option value="opt3">Option 3</option>
                                    <option value="opt4">Option 4</option>
                                </select> -->



                            <?php
                                                                 

                            wp_enqueue_script( 'wc-country-select' );
                            
                                woocommerce_form_field( 'billing_country', array(
                                    'type'      => 'country',
                                    'class'     => array('col-lg-6 col-md-6 col-sm-12 col-12 form-split'),
                                    'label'     => __('Country'),
                                    'placeholder' => __('Choose your country.'),
                                    'required'  => true,
                                    'clear'     => true
                                ));

                                

                                woocommerce_form_field( 'billing_state', array(
                                    'type'      => 'state',
                                    'class'     => array('col-lg-6 col-md-6 col-sm-12 col-12 form-split'),
                                    'label'     => __('state'),
                                    'placeholder' => __('Choose your state.'),
                                    'required'  => true,
                                    'clear'     => true
                                ));
                                
                            ?>
                        
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>City<sup>*</sup></label>
                            <input id="city" name="city" type="text" class="form-control blog-form-in" placeholder="City">
                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Address</label>
                            <input id="address" name="address" type="text" class="form-control blog-form-in" placeholder="Ahmedabad">
                        </div>
                        <div class="col-lg-6 col-md-6 col-sm-12 col-12 form-split">
                            <label>Pincode</label>
                            <input id="postcode" name="postcode" type="text" class="form-control blog-form-in" placeholder="XXX XXX">
                        </div>

                        <div class="col-lg-12 col-md-12 col-sm-12 col-12 form-split btn-split">
                            <!-- <button type="btn" class="blog-form-submit btn">Sign Up</button> -->
                            <input id="addusersub" class="blog-form-submit btn" name="adduser" type="submit" value="Sign Up">
                            <div class="errormsg" style="display: none; color: red;"></div>
                            <h2 class="validation"></h2>
                            <p>
                                <input id="action" name="action" type="hidden" value="adduser">
                                <input id="formname" name="formname" type="hidden" value="reg">
                            </p>

                        </div>



                        <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="signup-using">
                                <h5>Signup Using</h5>
                                <ul>
                                    <li> <a href="#" class="su-ic"><i class="fa fa-twitter" aria-hidden="true"></i></a> </li>
                                    <li> <a href="#" class="su-ic"><i class="fa fa-facebook" aria-hidden="true"></i></a> </li>
                                    <li> <a href="#" class="su-ic"><i class="fa fa-google-plus" aria-hidden="true"></i></a> </li>
                                </ul>
                                <p>Alreddy have an Account? <a href="#loginModal" data-toggle="modal" data-dismiss="modal" class="login-link">Login</a> </p>
                            </div>
                        </div>

                    </div>
                </form>



<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.validate.js"></script>



<script>
 jQuery(document).ready(function() {
        $("#adduser").validate({

            submitHandler: function() {

                $.ajax({
                    type: "POST",
                    url: '<?php echo get_template_directory_uri(); ?>/template-parts/reg-ajax.php',
                    data: $("#adduser").serialize(),
                    success: function(response) {

                        if (response == 1) {
                            $('.plswait').hide();
                            $('.success').show().delay(8000).fadeOut();;
                            $('.validation').delay(8000).fadeOut();
                            //window.location.href = "<?php echo site_url(); ?>";
                            //$('#signin-model').modal('show');
                            $('#adduser')[0].reset();


                        } else {

                            $('.errormsg').show();
                            $('.errormsg').html("<span>" + response + "</span>");
                            $('.plswait').hide();

                        }
                    }
                });
            },
            rules: {

                fullname: {
                    required: true,

                },

                lastname: {
                    required: true,

                },
                pass: {
                    minlength: 5
                },
                cpass: {
                    required: true,
                    equalTo: "#pass"
                },


                email: {
                    required: true,
                    email: true
                },
                phone: {
                    required: true,
                    number: true,
                    maxlength: 16,
                    minlength: 10,
                },


            },
            messages: {

                username: {
                    required: "Please enter fullname",

                },
                pass: {
                    required: "Please provide a password",
                    minlength: "Your password must be at least 5 characters long"
                },

                email: {
                    required: "Please enter a valid email address",
                },
                phone: {
                    required: "Please provide phone number",

                },

            }
        });
    });
</script>




