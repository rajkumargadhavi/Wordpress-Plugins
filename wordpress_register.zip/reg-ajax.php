<?php 
include('../../../../wp-config.php');
global $wpdb;
 $user=$_POST['fullname']; 
 $email=$_POST['email'];
$fname=$_POST['fullname'];
$lname=$_POST['fullname'];
$phone = $_POST['p_code'].$_POST['phone'];
$pass= $_POST['pass'];
$date=date('Y-m-d H:i:s');

$country= $_POST['billing_country'];
$state= $_POST['billing_state'];
$city= $_POST['city'];
$address= $_POST['address'];
$postcode= $_POST['postcode'];

$table = $wpdb->prefix."users";
$sel= "Select * from $table  where user_login= '".$email."'";
$posts = $wpdb->get_results($sel);
$rowCount = $wpdb->num_rows;

if($rowCount > 1 )
{
	echo 'user already exsits';
   
}else{
		 
		$default_newuser = array(
        'user_pass' => $pass,
        'user_login' => $email,
        'user_email' => $email,
        'first_name' => $fname,
        'role' => 'customer',
        ); 
		
        $users = wp_insert_user( $default_newuser );
		
		if ( ! is_wp_error( $users ) ) {

			add_user_meta( $users, 'billing_state', $state );
			add_user_meta( $users, 'billing_city', $city );
			add_user_meta( $users, 'billing_phone', $phone );
			add_user_meta( $users, 'billing_address_1', $address );
			add_user_meta( $users, 'billing_postcode', $postcode );
			add_user_meta( $users, 'billing_country', $country );

			echo 'Registration complete.';  
		}
		
		else{
			echo "User Already Exists. Please try with another Email Address.";
      
		}
		
       
	
    }

?>