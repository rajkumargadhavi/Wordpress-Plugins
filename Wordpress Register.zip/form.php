

<div class="sign-up padd-rite">
                        <h2>Sign Up Form</h2>
                        <div class="line_col"></div>
                        <form id="adduser" class="user-forms" action="" autocomplete="on" method="post" name="reg_form">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="firstname">
                                            <?php echo 'Full Name'; ?><span class="after">*</span></label>
                                        <input id="fullname" class="text-input form-control" name="fullname" type="text" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="lastname">
                                            <?php echo 'Last Name'; ?><span class="after">*</span></label>
                                        <input id="lastname" class="text-input form-control" name="lastname" required="required" type="text" value="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6 ">
                                    <div class="form-group">
                                        <label for="user_email">
                                            <?php echo 'Email'; ?><span class="after">*</span></label>
                                        <input id="email" class="text-input form-control" name="email" required="required" type="email" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="password">
                                            <?php echo 'Password'; ?><span class="after">*</span></label>
                                        <input id="pass" class="text-input form-control" name="pass" required="required" type="password" value="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="password">
                                            <?php echo 'Confirm Password'; ?><span class="after">*</span></label>
                                        <input id="cpass" class="text-input form-control" name="cpass" required="required" type="password" value="">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="phone">
                                            <?php echo 'Phone Number'; ?><span class="after">*</span></label>
                                        <input id="phone" class="text-input form-control" name="phone" type="tel" value="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <p class="form-submit">
                                        <input id="addusersub" class=" contact-submit" name="adduser" type="submit" value="Register">
                                    </p>
                                    <div class="errormsg" style="display: none; color: red;"></div>
                                    <h2 class="validation"></h2>
                                    <p>
                                        <input id="action" name="action" type="hidden" value="adduser">
                                        <input id="formname" name="formname" type="hidden" value="reg">
                                    </p>
                                </div>
                            </div>
                        </form>
                    </div>



<script src="<?php echo get_template_directory_uri(); ?>/js/jquery.validate.js"></script>



<script>
jQuery(document).ready(function()
{
    $("#adduser").validate({

    submitHandler: function() 
    {
        
            $.ajax({
            type: "POST",
            url: '<?php echo get_template_directory_uri(); ?>/template-parts/reg-ajax.php',
            data: $("#adduser").serialize(),
            success: function(response){  
        
                if(response==1)
                { 
                    $('.plswait').hide(); 
                    $('.success').show().delay(8000).fadeOut();;
                    $('.validation').delay(8000).fadeOut();
                    //window.location.href = "<?php echo site_url(); ?>";
                    //$('#signin-model').modal('show');
                    $('#adduser')[0].reset();

             
                }else{
        
                    $('.errormsg').show();
                    $('.errormsg').html("<span>"+response+"</span>");
                    $('.plswait').hide();
                    
                }   
            }
            });
},  
rules: {

        fullname: {
            required: true,
            
        },
        
        lastname: {
            required: true,
            
        },
        pass: {
                minlength: 5
        },
        cpass: {
            required: true,
            equalTo: "#pass"
        },
        
        
        email: {
            required: true,
            email: true
        },
        phone: {
            required: true,
            number: true,
            maxlength:16,
            minlength:10,
        },
        
        
    },
    messages: {
        
        username: {
            required: "Please enter fullname",
            
        },
        pass: {
            required: "Please provide a password",
            minlength: "Your password must be at least 5 characters long"
        },
        
        email: { 
        required:"Please enter a valid email address",
        },
        phone: {
            required: "Please provide phone number",
            
        },
        
    }
    });
});
</script>




