<?php 
include('../../../../wp-config.php');
global $wpdb;
 $user=$_POST['fullname']; 
 $email=$_POST['email'];
$fname=$_POST['fullname'];
$lname=$_POST['lastname'];
$phone = $_POST['phone'];
$pass= $_POST['pass'];
$date=date('Y-m-d H:i:s');
$table = $wpdb->prefix."users";
$sel= "Select * from $table  where user_login= '".$email."'";
$posts = $wpdb->get_results($sel);
$rowCount = $wpdb->num_rows;

if($rowCount > 1 )
{
	echo 'user already exsits';
   
}else{
		 
		$default_newuser = array(
        'user_pass' => $pass,
        'user_login' => $email,
        'user_email' => $email,
        'first_name' => $fname,
		'last_name'     =>  $lname,
        'role' => 'customer'
        ); 
		
        $users = wp_insert_user( $default_newuser );
		
		if ( ! is_wp_error( $users ) ) {
			echo 'Registration complete.  Go to <a href="' . get_site_url() . '/login">login page</a>.';  
		}
		
		else{
			echo "User Already Exists. Please try with another Email Address.";
			
		}
		
       
	
    }

?>